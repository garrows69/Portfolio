/*
 * If you modify this file, replace this with your own header
 * Otherwise, leave this file and this comment as-is
 */

#ifndef BINTREE_FUNCTIONS_H
#define BINTREE_FUNCTIONS_H

#include <iostream>

int random_range(int, int);

#endif /* BINTREE_HEADER_H */

