/*
 * Do not modify this file
 */


#ifndef BINTREE_MAIN_H
#define BINTREE_MAIN_H

#include <iostream>
#include "bintree.h"
#include "functions.h"

#define TESTDATA1 7
#define TESTDATA2 6

using std::cout;
using std::endl;

#endif /* BINTREE_MAIN_H */

